
import './App.css';
import React, {useState} from 'react';
import ColorDisplay from './Components/BoxDisplay';
import BoxForm from './Components/ColorInput';


function App() {
  
  const[currentColor, setCurrentColor] = useState([])

  const gotNewColor = (newColor) => {setCurrentColor([...currentColor, newColor])};

  return (
    <div className="App">
      <BoxForm onNewColor={gotNewColor}/>
      <ColorDisplay colors={currentColor}/>
    </div>
  );
}

export default App;
