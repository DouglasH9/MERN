import React from "react";

const ColorDisplay = (props) => {
    return (
        <>
            <div id="boxContainer">
                {props.colors.map((color) => {
                    return (<div id="colorBox" style={{backgroundColor: color}}></div>)
                })}
            </div>
            
        </>
    );
};

export default ColorDisplay;