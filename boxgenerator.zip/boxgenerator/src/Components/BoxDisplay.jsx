import React from "react";

const ColorDisplay = (props) => {
    return (
        <>
            <div>
                {props.currentColor.map(() => {
                    return (<div id="colorBox" style={{backgroundColor: props.currentColor}}></div>)
                })}
            </div>
            
        </>
    );
};

export default ColorDisplay;