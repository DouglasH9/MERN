import React, {useState} from "react";

const BoxForm = (props) => {
    const [color, setColor] = useState("");

    const handleSubmit = (e) => {
        e.preventDefault();
        props.onNewColor(color);
        setColor("");
    };

    return (
        <>
            <form onSubmit={handleSubmit}>
                <h1>Please enter a color!</h1>
                <input type="text" name="colorHandler" onChange={ (e) => setColor(e.target.value)} value={color}/>
                <input type="submit" value="Set Color"/>
            </form>
        </>
    )

}

export default BoxForm;